const SET_LOGIN_PENDING = 'SET_LOGIN_PENDING';
const SET_LOGIN_SUCCESS = 'SET_LOGIN_SUCCESS';
const SET_LOGIN_ERROR = 'SET_LOGIN_ERROR';

export function login(username, password) {
  return dispatch => {
    dispatch(setLoginPending(true));
    dispatch(setLoginSuccess(false));
    dispatch(setLoginError(null));

    callLoginApi(username, password, error => {
      dispatch(setLoginPending(false));
      if (!error) {
        dispatch(setLoginSuccess(true));
      } else {
        dispatch(setLoginError(error));
      }
    });
  }
}

function setLoginPending(isLoginPending) {
  return {
    type: SET_LOGIN_PENDING,
    isLoginPending
  };
}

function setLoginSuccess(isLoginSuccess) {
  return {
    type: SET_LOGIN_SUCCESS,
    isLoginSuccess
  };
}

function setLoginError(loginError) {
  return {
    type: SET_LOGIN_ERROR,
    loginError
  }
}

function callLoginApi(username, password, callback) {
    const users = [
      { id: 1, name: "abi", password: "ab" },
      { id: 2, name: "pank", password: "pan" },
      { id: 3, name: "frank", password: "fra" },
      { id: 4, name: "rama", password: "ram" },
      { id: 5, name: "shan", password: "sha" },
      { id: 6, name: "prak", password: "pra" },
      { id: 7, name: "nancy", password: "nan" },
      { id: 8, name: "suji", password: "suj" },
      { id: 9, name: "tresa", password: "tre" },
      { id: 10, name: "naomi", password: "nao" }
    ];
    const hasAdmins = users.find(item => item.name === username);
    const hasPassword = users.find( item => item.password === password);
    if(hasAdmins === undefined || hasPassword===undefined)
    {
      return callback(new Error('Invalid email and password'));
    }
    else{
    setTimeout(() => {
    if (hasAdmins.id === hasPassword.id) {
      return callback(null);
    } 
    else {
      return callback(new Error('Invalid email and password'));
    }
  }, 1000);
}
}


export default function reducer(state = {
  isLoginSuccess: false,
  isLoginPending: false,
  loginError: null
}, action) {
  switch (action.type) {
    case SET_LOGIN_PENDING:
      return Object.assign({}, state, {
        isLoginPending: action.isLoginPending
      });

    case SET_LOGIN_SUCCESS:
      return Object.assign({}, state, {
        isLoginSuccess: action.isLoginSuccess
      });

    case SET_LOGIN_ERROR:
      return Object.assign({}, state, {
        loginError: action.loginError
      });

    default:
      return state;
  }
}